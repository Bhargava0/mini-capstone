-- productline ,yea
SELECT product_line,YEAR(order_date) AS Year, MONTH(order_date) month, SUM(total_amount) AS Total_Sales FROM amazon
GROUP BY product_line,order_date
order by total_sales desc;

SELECT Product_Line, SUM(Total_amount) AS Total_sales,avg(Unit_Price) AS Avg_Unit_Price,sum(quantity) as total_quntity 
FROM amazon
GROUP BY Product_Line
ORDER BY Total_sales DESC;


-- total sales by month
select  month ,sum(total_amount) as total_sales, sum(quantity) total_quantity,
avg(total_amount) as avg_sales, avg(quantity) avg_quantity from amazon
group by month
order by sum(total_amount) desc;



select product_line,gender,month,sum(total_amount) totalsales, sum(quantity) totalquantitysold from amazon
group by product_line,gender,month
order by sum(total_amount) asc
limit 10 ;
