-- This analysis aims to uncover the different customer segments, purchase trends and the profitability of each customer segment.


SELECT customer_type, COUNT(*) AS num_customers, SUM(total_amount) AS total_revenue,
AVG(total_amount) AS avg_order_value,
SUM(cogs) AS total_cogs, SUM(gross_income) AS total_gross_income,
AVG(gross_margin_percentage) AS avg_gross_margin_percentage
FROM amazon
GROUP BY customer_type;