-- product line perfomance
SELECT Product_Line, SUM(Total_amount) AS Total_sales,avg(Unit_Price) AS Avg_Unit_Price,sum(quantity) as total_quntity 
FROM amazon
GROUP BY Product_Line
ORDER BY Total_sales DESC;

-- top performents
select product_line, gender,month, sum(total_amount) total_amount from amazon
group by product_line,gender,month
order by total_amount desc;

-- total sales by gener
select gender ,sum(total_amount) as total_sales, sum(quantity) total_quantity from amazon
group by gender
order by total_sales;



-- Calculate product line value
SELECT product_line,SUM(total_amount) AS total_sales,(SUM(total_amount) / (SELECT SUM(total_amount) FROM amazon)) * 100 AS market_share
FROM amazon
GROUP BY product_line
ORDER BY market_share DESC;