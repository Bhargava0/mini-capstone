# Business Questions To Answer
# 1.What is the count of distinct cities in the dataset?
select distinct city ,count(*) as countOFcity  from amazon
group by city;

#2.For each branch, what is the corresponding city?
select branch, count(city) as city_count from amazon
group by branch ;

#3.What is the count of distinct product lines in the dataset?
select distinct product_line from amazon;

#4.Which payment method occurs most frequently?
select payment_type, count(*) as totalpayments from amazon
group by payment_type;

#5.Which product line has the highest sales?
select product_line,sum(quantity) totalquantity from amazon
group by product_line
order by totalquantity desc
limit 3;

#6.How much revenue is generated each month?
select MONTH(order_date) as month, sum(total) as total_revenue from amazon
group by month;

#7. which month did the cost of goods sold reach its peak?
select month, sum(cogs) as total_cost_of_gods from amazon
group by month
order by sum(cogs) desc
limit 1;

#8.Which product line generated the highest revenue?
select product_line , sum(unit_price * quantity) as revenue from amazon
group by product_line
order by revenue desc
limit 1;

#9.In which city was the highest revenue recorded?
select city, sum(total_amount) totalrevenue from amazon
group by city 
order by totalrevenue desc
limit 1;

#10.Which product line incurred the highest Value Added Tax?
select product_line,sum(tax) as tax from amazon
group by product_line
order by tax desc
limit 1;

#11.For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."
select product_line ,sum(total_amount) total_sales,avg(total_amount) avg_sales,
case
	when sum(total_amount) > avg(total_amount) then "good"
    end "bad"
    from amazon
group by product_line
order by total_sales desc;

#12.Identify the branch that exceeded the average number of products sold.
 select branch,sum(quantity) total_quantity,avg(quantity ) avg_quantity from amazon
group by branch
 having avg_quantity > total_quantity;
 

#13.Which product line is most frequently associated with each gender?
select product_line ,gender ,count(*) count from amazon
group by product_line,gender
order by count desc;

#14.Calculate the average rating for each product line.
select product_line, avg(rating) avg_rating from amazon
group by product_line
order by avg(rating) desc;

#15.Count the sales occurrences for each time of day on every weekday.
SELECT day, COUNT(*) AS sales_count
FROM amazon

GROUP BY day;

#16.Identify the customer type contributing the highest revenue.
select customer_type, sum(total_amount) revenue from amazon
group by customer_type
order by revenue desc
limit 1;

#17.Determine the city with the highest VAT percentage.

select city, (sum(tax) / sum(total_amount) )* 100 vat_percentege from amazon
group by city
order by vat_percentege desc;


#18.Identify the customer type with the highest VAT payments.
select customer_type, (sum(tax) / sum(total_amount)) * 100  tax_payer_type from amazon
group by customer_type
order by tax_payer_type;

#19.What is the count of distinct customer types in the dataset?
select count(distinct customer_type) count_of_customertype from amazon
;

#20.What is the count of distinct payment methods in the dataset?
select count(distinct payment_method) count_of_oayment_methods from amazon
;

#21.Which customer type occurs most frequently?
select customer_type, count(*)count from amazon
group by customer_type
order by count desc
limit 1;

#22.Identify the customer type with the highest purchase frequency.
select customer_type,count(invoice_id) purchasing_frequency from amazon
group by customer_type
order by purchasing_frequency desc
limit 1;
#23.Determine the predominant gender among customers.
select gender ,count(*) count from amazon
group by gender
order by count desc
limit 1;

#24.Examine the distribution of genders within each branch.
select branch, gender ,count(*) count_of_gender from amazon
group by branch,gender
order by count(gender);
#25.Identify the time of day when customers provide the most ratings.
select timeofday,count(*) rating from amazon
group by timeofday
order by rating desc;
#26.Determine the time of day with the highest customer ratings for each branch.
select branch, timeofday,max(rating) rating from amazon
group by branch, timeofday
order by max(rating) desc;
#27.Identify the day of the week with the highest average ratings.
select day ,avg(rating) avg_rating from amazon
group by day
order by avg(rating)desc
limit 1;

#28.Determine the day of the week with the highest average ratings for each branch.
WITH avgratingsperDay AS (
SELECT
branch,day,AVG(rating) AS avg_rating FROM amazon
GROUP BY branch,day
)
SELECT branch,day,avg_rating FROM avgratingsperDay
WHERE (branch, avg_rating) IN (
SELECT branch, max(avg_rating) FROM avgratingsperDay
GROUP BY branch
);
